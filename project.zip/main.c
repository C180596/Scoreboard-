/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include<stdio.h>
#include<conio.h>
#include<string.h>
struct cricketer{
   char Player[550];
   int R;
   int B;
  int FOUR;
  int SIX;
   int O;
   int M;
   int Run;
   int W;
 
   float avrn,Eco;
   char temp;
};
struct cricketer c[120],temp1,temp2;
void main() {
   int i,j,k,l;
   for(i=0;i<2;i++){
      printf("Enter the name of Batsman: %d\n",i+1);
      printf("Player : ");
      gets(c[i].Player);
      printf("\nR: ");
      scanf("%d",&c[i].R);
      printf("\nB: ");
      scanf("%d",&c[i].B);
       printf("\nFOUR: ");
      scanf("%d",&c[i].FOUR);
      printf("\nSIX: ");
      scanf("%d",&c[i].SIX);
      printf("\n\nSR : ");
      scanf("%f",&c[i].avrn);
      scanf("%c",&c[i].temp);
      
   }
      for(k=0;k<2;k++){
       printf("Enter the name of Bowler: %d\n",k+1);
       printf("Player : ");
      gets(c[k].Player);
        printf("\nO: ");
      scanf("%d",&c[k].O);
        printf("\nM: ");
      scanf("%d",&c[k].M);
        printf("\nRun: ");
      scanf("%d",&c[k].Run);
        printf("\nW: ");
      scanf("%d",&c[k].W);
      printf("\n\nEc : ");
      scanf("%f",&c[k].Eco);
      scanf("%c",&c[k].temp);
     
   }
   
for(i=0;i<2;i++) {
for(j=i+1;j<2;j++) {
if(c[i].avrn > c[j].avrn){

temp1=c[i];
c[i]=c[j];
c[j]=temp1;
}
}
 }

 printf("                     IND vs SL ,Final               \n ");
     printf("\n____________________________________________________________\n");
     printf("\nMatch : \nIND vs SL, ICC World Cup 2011. \n\n");
     
     printf("\nVenue : \nWankhede Stadium, Mumbai.\n ");
    
   printf("Indian innings                                50 OVERS\n");
    printf(" \nBatting\n");
   printf("\n____________________________________________________________\n");
    printf("Sr No\tPlayer\tR\tB\tFOUR\tSIX\tSR\n");
   printf("____________________________________________________________\n\n");
    
   for(i=0;i<2;i++){
      printf("%d\t%s\t%d\t%d\t%d\t%d\t%f\n\n\n ",i+1 ,c[i].Player,c[i].R,c[i].B,c[i].FOUR,c[i].SIX,c[i].avrn);
 printf("____________________________________________________________\n\n");
        
   }
for(k=0;k<2;k++) {
for(l=k+1;l<2;l++) {
if(c[k].Eco > c[l].Eco){

temp2=c[k];
c[k]=c[l];
c[l]=temp2;
}
}
}



       printf(" Bowler");
        printf("\n____________________________________________________________\n");
        printf("Sr No\tPlayer\tO\tM\tRun\tW\tEc\n");
  printf("____________________________________________________________\n\n");
        for(k=0;k<2;k++){
                printf("%d\t%s\t%d\t%d\t%d\t%d\t%f\n\n\n ",k+1 ,c[k].Player,c[k].O,c[k].M,c[k].Run,c[k].W,c[k].Eco);
               printf("____________________________________________________________\n\n"); 
              
        }
                                   printf("\n\n***IND WON THIS MATCH***") ;
                                   printf("\nMan of the match : Dhoni");
                                   printf("\nMan of the series : Yuvraj");
                                   printf("\n*****Congratulations team India**** ");
                
          
}       
      

   







